// Definir variáveis do jogo
let player;
let milho;
let feira;
let milhoColetado = 0;
let pontos = 0;
let textoAnimadoY = 20;  // Posição inicial do texto animado

function setup() {
  // Criar a tela do jogo
  createCanvas(600, 400);
  
  // Iniciar o personagem
  player = new Player();
  
  // Criar a posição aleatória do milho
  milho = createVector(random(width), random(height));
  
  // Definir a posição da feira (onde o jogador deve vender o milho)
  feira = createVector(width - 50, height / 2);
}

function draw() {
  // Limpar o fundo da tela
  background(220);
  
  // Mostrar o texto explicativo animado
  mostrarTextoAnimado();
  
  // Mostrar o texto do jogo
  textSize(16);
  fill(0);
  text('Milho coletado: ' + milhoColetado, 10, 20);
  text('Pontos: ' + pontos, 10, 40);
  
  // Desenhar o milho
  fill(255, 204, 0);
  ellipse(milho.x, milho.y, 30, 30);  // Exibe o milho como círculo
  
  // Desenhar a feira
  fill(0, 255, 0);
  rect(feira.x - 20, feira.y - 20, 40, 40);  // Exibe a feira como um quadrado
  
  // Movimentar o personagem
  player.update();
  player.display();
  
  // Checar se o jogador coletou o milho
  if (dist(player.x, player.y, milho.x, milho.y) < 20) {
    milhoColetado++;
    pontos += 10;  // A cada milho coletado, o jogador ganha 10 pontos.
    milho = createVector(random(width), random(height));  // Coloca um novo milho em uma posição aleatória.
  }
  
  // Checar se o jogador chegou à feira
  if (dist(player.x, player.y, feira.x, feira.y) < 30 && milhoColetado > 0) {
    milhoColetado = 0;  // O jogador vende o milho e o contador de milho é resetado
    pontos += 50;  // Vende o milho na feira e ganha mais pontos
    milho = createVector(random(width), random(height));  // Novo milho aparece
  }
}

// Função para exibir o texto animado na tela
function mostrarTextoAnimado() {
  fill(255, 0, 0);  // Cor vermelha para o texto
  textSize(20);
  textAlign(CENTER);
  text("Colete o milho para vendê-lo na feira da cidade", width / 2, textoAnimadoY);
  
  // Animação do texto
  textoAnimadoY += 0.5;  // Movimento para baixo (animação suave)
  
  // Se o texto sair da tela, reseta a posição
  if (textoAnimadoY > height) {
    textoAnimadoY = -30;  // Coloca o texto de volta no topo
  }
}

// Classe para o jogador
class Player {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.size = 30; // Aumentei o tamanho do personagem
    this.speed = 5;
  }
  
  // Atualiza a posição do jogador com as setas do teclado
  update() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }
  }
  
  // Exibe o jogador na tela
  display() {
    fill(0, 0, 255);  // Cor azul para o personagem
    ellipse(this.x, this.y, this.size, this.size);  // Exibe o personagem como círculo
  }
}
